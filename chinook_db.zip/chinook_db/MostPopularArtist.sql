select art.Name, count(il.TrackId) as TotalTracksPurchased
from Artist art join album  alb
on art.ArtistId= alb.ArtistId 
join track t 
on alb.AlbumId=t.AlbumId
join InvoiceLine il
on t.TrackId=il.TrackId
group by art.Name
order by  count(il.TrackId) DESC
