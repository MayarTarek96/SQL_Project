select m.name, count(m.MediaTypeId) as MediaTypesPurchases
from MediaType m
join track t
on t.MediaTypeId=m.MediaTypeId
join InvoiceLine il
on il.TrackId=t.TrackId
group by m.name
order by MediaTypesPurchases