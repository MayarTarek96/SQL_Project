select  g.name as GenreTitle, count(g.name) as NumberOfTracks
from genre g
join track t
on t.GenreId=g.GenreId
join invoiceline il
on il.trackid=t.trackid
join invoice i
on i.InvoiceId=il.InvoiceId
join Customer c
on c.CustomerId=i.CustomerId
group by g.name
order by MostPopularGenre DESC