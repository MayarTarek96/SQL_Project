
with t1 as(select e.FirstName as FirstName, e.LastName as LastName ,count(c.SupportRepId)  as TotalNumberOfCustomers
from Employee e
join customer c
on e.EmployeeId=c.SupportRepId
group by e.EmployeeId
order by count(c.SupportRepId) DESC),


t2 as(select e.FirstName as FirstName,count(i.CustomerId) as TotalNumberOfInvoices
from Employee e
join customer c
on e.EmployeeId=c.SupportRepId
join invoice i
on c.CustomerId=i.CustomerId
group by e.FirstName
order by count(i.CustomerId) DESC)

select t1.FirstName,t1.LastName,t1.TotalNumberOfCustomers,t2.TotalNumberOfInvoices
from t1
join t2
on t1.FirstName=t2.FirstName
group by t1.FirstName
order by t1.TotalNumberOfCustomers
